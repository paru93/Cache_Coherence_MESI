///////////////////////////////////////
// File Name: MESICtrllr.h
// Author: Chetan 
//
///////////////////////////////////////

#ifndef MESI_CTRLLR_H
#define MESI_CTRLLR_H

void MESICtrllr(unsigned char , unsigned char , unsigned char *, unsigned char);

#endif // MESI_CTRLLR_H
