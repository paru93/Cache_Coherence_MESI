///////////////////////////////////////
// File Name: CacheMem.h
// Author: Chetan
//
///////////////////////////////////////

#ifndef _CACHE_MEM_H
#define _CACHE_MEM_H

typedef struct
{
	unsigned char mesi;
	unsigned char data;
	int tag;
}CacheMem_t;

#endif
