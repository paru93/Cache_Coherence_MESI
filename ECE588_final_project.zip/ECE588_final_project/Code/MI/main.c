/** @file main.c
 *
 * @authors Chetan Bornarkar (bchetan@pdx.edu),Parimal Kulkarni (psk@pdx.edu),Ashish Patil (patil@pdx.edu)
 * Description:This file has implementation of MI coherence protocol. Reads inputs from file procID_address_rw_data.txt
 * Configurable main memory and cache size by macro MAINLINESIZE and CACHELINESIZE respectively and configurable number of 
 * processors by macro MAXPROCS
*/

#include <stdio.h>
#include <stdlib.h>
#define CACHELATENCY 1
#define MAINMEMLATENCY 20
#define MAXPROCS 8
#define CACHELINESIZE 256//For testing
#define MAINLINESIZE 1024

int index_bits=0;
int index_mask=(CACHELINESIZE)-1;

typedef struct
{
	char proc_id;
	unsigned char index;
	int addr;
	char rw;
	int data;
	int tag;
}CacheCtrl_t;
unsigned char  read,write,readfrom_cache,readfrom_main_mem,writeback_main_mem;
int miscount=0,hitcount=0,memcycles=0,mainmemory_accesses=0;
typedef enum
{
	I = 0,
	M = 1
}MI_t;

typedef enum
{
	WRITE,
	READ
}memOpr_t;

typedef enum
{
	CACHE_EMPTY,
	FOUND_IN_CACHE,
	NOTFOUND_IN_CACHE
}CacheDataFind_t;

typedef struct
{
    char proc_id;
    int addr;
    char RW;
    int data;
} upReq_t;

typedef struct
{
    MI_t mi;
	int data;
	int tag;
}CacheMem_t;
static CacheMem_t  cacheMem[MAXPROCS][CACHELINESIZE];	// initialize the cache memory
int total_memory_latency=0;
CacheCtrl_t cc;
int ADDR,READWRITE,PR_ID;
unsigned int DATA;

unsigned int LOG2( unsigned int x )
{
  unsigned int ans = 0 ;
  while( x>>=1 ) ans++;
  return ans ;
}
const char* state_string(MI_t x)
{
   switch (x)
   {
      case M: return "M";
      case I: return "I";
   }
}

void MICtrllr(CacheCtrl_t *cc,unsigned char *writeback_main_mem,char Proc_ID)
{
    MI_t nextState;

	//Snoop
	if(Proc_ID!=cc->proc_id)
	{
		switch(cacheMem[Proc_ID-1][cc->index].mi)
		{
			case M: // This case will not arise because in invalid the Read/Write flags are set before entering
                    // this loop
					//when there is a writeback from snooping processor cache, tags match with the request hence the Invalidate the block
					if(*writeback_main_mem==1)
                    {
                        nextState=I;
                    }
                    else
                    {
                        nextState=M;
                    }
					break;

            case I:	nextState = I;
					break;

		}
	}
	else
    {
        switch(cacheMem[Proc_ID-1][cc->index].mi)
		{
			case M: nextState=M;
                    break;

            case I:	nextState = M;
					break;

        }

    }
	cacheMem[Proc_ID-1][cc->index].mi = nextState;
}


void cacheMemAddrCheck(CacheCtrl_t *cc,unsigned char *readfrom_main_mem, unsigned char *writeback_main_mem,char Proc_ID)
{
    // Clear the signals which are used to indicate the other cache or memory that the data was not found
    *readfrom_main_mem = 0;
    *writeback_main_mem = 0;


    // check if the cache location is empty or contains an invalid address/tag
    //For processor requesting the data
	if(cc->proc_id==Proc_ID)
	{

		if(cc->tag != cacheMem[Proc_ID-1][cc->index].tag || (cacheMem[Proc_ID-1][cc->index].mi==I))
		{
            // according to read/write operation the respective signal is asserted
			 miscount++;
			//when the cache has different tag at same address, evict and read from read new data at requested memory location
			if((cacheMem[Proc_ID-1][cc->index].mi==I))
            {
                *writeback_main_mem=0;

            }
			*readfrom_main_mem=1;
		}
		else
		{
			//Tags match hence read from cache
			hitcount++;
			memcycles+=CACHELATENCY;
		}
	}
    else    //snooping processor
    {
		if(cc->tag == cacheMem[Proc_ID-1][cc->index].tag && cacheMem[Proc_ID-1][cc->index].mi==M)
		{
			*writeback_main_mem = 1;
		}

    }
}
unsigned char CacheReadWrite(CacheCtrl_t *cc,char Proc_ID)
{
    if(cc->rw)
    {
        return (cacheMem[Proc_ID-1][cc->index].data);
    }
    else
    {
        cacheMem[Proc_ID-1][cc->index].data=cc->data;
        return (cc->data);
    }
}


void SharedMem(unsigned char RW,CacheCtrl_t *cc,char Proc_ID)
{
	static unsigned char mem[MAINLINESIZE] = {0};
	int eviction_address=0;
	int memory_address=0;

		if(RW)		// for read operation
		{

			memory_address=(cc->tag)<<index_bits | (cc->index);
			cacheMem[Proc_ID-1][cc->index].data=mem[memory_address];		// return the data requested from teh mem
            //printf("Memory address =%x\n",memory_address);
            // Update tag after eviction if the requester evicted the block
            if(Proc_ID==cc->proc_id)
            {
                cacheMem[Proc_ID-1][cc->index].tag=cc->tag;

            }
            //printf("cacheMem_containts=%d    data mem=%d\n",cacheMem[Proc_ID-1][cc->index].data,mem[memory_address]);
		}
		else		// for write operation
		{

			eviction_address=((cacheMem[Proc_ID-1][cc->index].tag)<<index_bits) | (cc->index);

			mem[eviction_address]=cacheMem[Proc_ID-1][cc->index].data;// write the data in the memory
		}


}
void cacheMem_initialize()
{
    int no_proc,cache_lines;
    for(no_proc=0;no_proc<MAXPROCS;no_proc++)
    {
        for(cache_lines=0;cache_lines<CACHELINESIZE;cache_lines++)
        {
            cacheMem[no_proc][cache_lines].data=0x0;
            cacheMem[no_proc][cache_lines].mi=I;
            cacheMem[no_proc][cache_lines].tag=0x0;
        }

    }

}
//format proc_ID address r/wbar data
//example: 1      0xaf5    1     0xaf00
//for read, data is internally assigned to 0
void update_snooper_response(CacheCtrl_t *cc,int snoop_id)
{
        int RW;
        //For snooping processors
        cacheMemAddrCheck(cc,&readfrom_main_mem,&writeback_main_mem,snoop_id);
        //printf("readfrom_main_mem=%d    writeback_main_mem=%d\n",readfrom_main_mem,writeback_main_mem);

    //if after snooper's response if tags matched, writeback and read from main memory
        if(writeback_main_mem==1)
        {
            RW=0;
            SharedMem(RW,cc,snoop_id);
            mainmemory_accesses++;
        }

        //Update the snooper's MI state
        MICtrllr(cc,&writeback_main_mem,snoop_id);

        writeback_main_mem=0;

        //For processor which has the bus
}


void update_master_response(CacheCtrl_t *cc)
{

        int RW=0;
        cacheMemAddrCheck(cc,&readfrom_main_mem,&writeback_main_mem,cc->proc_id);
        if(writeback_main_mem==1 || readfrom_main_mem==1)
        {
        //write followed by read
        //When tags don't match
            if(writeback_main_mem==1)
            {
                RW=0;
                SharedMem(RW,cc,cc->proc_id);
                mainmemory_accesses++;
            }
            RW=1;
            SharedMem(RW,cc,cc->proc_id);
            mainmemory_accesses++;
        }
        CacheReadWrite(cc,cc->proc_id);
        // printf("Cache snoop=%x  mi=%d   tag=%x\n",cacheMem[snoop_id][cc.index].data,cacheMem[snoop_id][cc.index].mi,cacheMem[snoop_id][cc.index].tag);
        MICtrllr(cc,&writeback_main_mem,cc->proc_id);
}
int main()
{
    index_bits=LOG2(CACHELINESIZE);
    FILE *fin,*fout;
    fin=fopen("procID_address_rw_data.txt","r");
    fout=fopen("output_log.txt","w");
    //printf("proc_ID address r/wbar data\n");
    int snoop_id;
    cacheMem_initialize();

    while(fscanf(fin,"%d 0x%x %d 0x%x\n",&PR_ID,&ADDR,&READWRITE,&DATA)!=EOF)
    {

        cc.addr=ADDR;
        cc.proc_id=PR_ID;
        cc.rw=READWRITE;
        printf("%d 0x%x %d 0x%x\n",PR_ID,ADDR,READWRITE,DATA);
        if(cc.rw==0)
        {
            cc.data=DATA;
        }
        else
        {
            cc.data=0;
        }

        cc.index=cc.addr&index_mask;
        cc.tag=cc.addr>>index_bits;

        for(snoop_id=1;snoop_id<=MAXPROCS;snoop_id++)
        {
            if(snoop_id==cc.proc_id)
            {
                continue;
            }
            else
            {
             update_snooper_response(&cc,snoop_id);

            }

        }


        update_master_response(&cc);
        printf("Proc1 Cache data=%x  MI=%s  at tag=%x index=%x\t",cacheMem[0][cc.index].data,state_string(cacheMem[0][cc.index].mi),cacheMem[0][cc.index].tag,cc.index);
        fprintf(fout,"Proc1 Cache data=%x  MI=%s  at tag=%x index=%x\t",cacheMem[0][cc.index].data,state_string(cacheMem[0][cc.index].mi),cacheMem[0][cc.index].tag,cc.index);

        printf("Proc2 Cache data=%x  MI=%s   at tag=%x index=%x\n",cacheMem[1][cc.index].data,state_string(cacheMem[1][cc.index].mi),cacheMem[1][cc.index].tag,cc.index);
        fprintf(fout,"Proc2 Cache data=%x  MI=%s   at tag=%x index=%x\n",cacheMem[1][cc.index].data,state_string(cacheMem[1][cc.index].mi),cacheMem[1][cc.index].tag,cc.index);

        printf("Proc3 Cache data=%x  MI=%s   at tag=%x index=%x\t",cacheMem[2][cc.index].data,state_string(cacheMem[2][cc.index].mi),cacheMem[2][cc.index].tag,cc.index);
        fprintf(fout,"Proc3 Cache data=%x  MI=%s   at tag=%x index=%x\t",cacheMem[2][cc.index].data,state_string(cacheMem[2][cc.index].mi),cacheMem[2][cc.index].tag,cc.index);

        printf("Proc4 Cache data=%x  MI=%s   at tag=%x index=%x\n",cacheMem[3][cc.index].data,state_string(cacheMem[3][cc.index].mi),cacheMem[3][cc.index].tag,cc.index);
        fprintf(fout,"Proc4 Cache data=%x  MI=%s   at tag=%x index=%x\n",cacheMem[3][cc.index].data,state_string(cacheMem[3][cc.index].mi),cacheMem[3][cc.index].tag,cc.index);

       }
    printf("Hits:%d   Misses:%d    Main memory accesses:%d\n",hitcount,miscount,mainmemory_accesses);
    fprintf(fout,"Hits:%d   Misses:%d    Main memory accesses:%d\n",hitcount,miscount,mainmemory_accesses);
    return 0;
}

