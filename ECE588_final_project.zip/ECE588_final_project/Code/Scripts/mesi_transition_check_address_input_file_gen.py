from random import randint
import os
import math
address=0
proc_id=0
rw=0
data=0
def generator(no_memory_lines,no_cache_lines):
    tag_range=int(no_memory_lines/no_cache_lines)
    index_bits=int(math.log2(no_cache_lines))
    for addressgen in range(0,no_cache_lines):
        fp.write(str(1)+" "+hex(addressgen)+" "+str(0)+" "+hex(randint(1,256))+" "+'\n')
        fp.write(str(1)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(1)+" "+hex(addressgen)+" "+str(0)+" "+hex(randint(1,256))+" "+'\n')
        fp.write(str(1)+" "+hex(3<<index_bits|addressgen)+" "+str(0)+" "+hex(randint(1,256))+" "+'\n')
        fp.write(str(1)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(1)+" "+hex(3<<index_bits|addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(2)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(1)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(2)+" "+hex(addressgen)+" "+str(0)+" "+hex(randint(1,256))+" "+'\n')
        fp.write(str(1)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(2)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(3)+" "+hex(addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(4)+" "+hex(3<<index_bits|addressgen)+" "+str(0)+" "+hex(randint(1,256))+" "+'\n')
        fp.write(str(1)+" "+hex(3<<index_bits|addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(2)+" "+hex(3<<index_bits|addressgen)+" "+str(1)+" "+'\n')
        fp.write(str(3)+" "+hex(3<<index_bits|addressgen)+" "+str(1)+" "+'\n')
        
     
    '''    
    for i in range(0,no_transactions):
        if(i==no_transactions-1):
            a=''
        else:
            a='\n'
        proc_id=str(randint(1,15)%no_processors + 1)
        address=randint(1,no_memory_lines)
        rw=(randint(1,15)%2)
        data=randint(1,256)                        
        if(rw==1):            
            fp.write(proc_id+" "+hex(address)+" "+str(rw)+" "+a)
        else:
            fp.write(proc_id+" "+hex(address)+" "+str(rw)+" "+hex(data)+a)
    '''
    fp.close()

os.chdir(os.getcwd())
fp=open("mesi_tester.txt","w")
x=[]
no_memory_lines=int(input(' No. of memory lines:'))
no_cache_lines=int(input('No. of cache lines:'))

generator(no_memory_lines,no_cache_lines)
