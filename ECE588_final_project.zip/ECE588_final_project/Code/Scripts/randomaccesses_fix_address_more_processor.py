from random import randint
import os
import math
address=0
proc_id=0
rw=0
data=0
address=[0xfa,0x1fa,0x2fa,0x3fa]
def generator(no_memory_lines,no_cache_lines,no_processors,no_transactions):
    tag_range=int(no_memory_lines/no_cache_lines)
    index_bits=int(math.log2(no_cache_lines))
    for addressgen in range(0,no_cache_lines):
        address=[]
        for tag_iterator in range(0,tag_range):
            address.append(tag_iterator<<index_bits|addressgen)
            
        for proc_iterator in range(0,no_processors):
            if(proc_iterator<tag_range):
                proc_id=str(proc_iterator+1)
                rw=1
                fp.write(proc_id+" "+hex(address[proc_iterator])+" "+str(rw)+" "+'\n')
            else:
                continue
        for i in range(0,no_transactions):
            if(i==no_transactions-1):
                a='\n'
            else:
                a='\n'
            proc_id=str(randint(1,15)%no_processors + 1)
            rw=(randint(1,15)%2)
            data=randint(1,256)                        
            if(rw==1):            
                fp.write(proc_id+" "+hex(address[randint(0,3)])+" "+str(rw)+" "+a)
            else:
                fp.write(proc_id+" "+hex(address[randint(0,3)])+" "+str(rw)+" "+hex(data)+a)
     
    '''    
    for i in range(0,no_transactions):
        if(i==no_transactions-1):
            a=''
        else:
            a='\n'
        proc_id=str(randint(1,15)%no_processors + 1)
        address=randint(1,no_memory_lines)
        rw=(randint(1,15)%2)
        data=randint(1,256)                        
        if(rw==1):            
            fp.write(proc_id+" "+hex(address)+" "+str(rw)+" "+a)
        else:
            fp.write(proc_id+" "+hex(address)+" "+str(rw)+" "+hex(data)+a)
    '''
    fp.close()

os.chdir(os.getcwd())
fp=open("procID_address_rw_data.txt","w")
x=[]
no_memory_lines=int(input(' No. of memory lines:'))
no_cache_lines=int(input('No. of cache lines:'))
no_processors=int(input('No. of processors:'))
no_transactions=int(input('No. of read write transactions:'))

generator(no_memory_lines,no_cache_lines,no_processors,no_transactions)
