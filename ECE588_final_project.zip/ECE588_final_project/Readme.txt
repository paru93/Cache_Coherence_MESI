The Code Folder contains:
"MI", "MESI", "Scripts" folders

The "MI" folder contains
-main.c---Implementation of MI protocol
All other folders "2_processor" "4_processor"
"8_processor" "startegy1_1" and "startegy1"
has text file named "procID_address_rw_data" 
which contains the tests used for various strategies

The "MESI" folder contains
-main.c---Implementation of MESI protocol and supporting files
All other folders "2_processor" "4_processor"
"8_processor" "startegy1_1" and "startegy1"
has text file named "instr" 
which contains the tests used for various strategies


The "Report" folder contains
-ECE588_FinalProject_Document(Final project report)


How to run the program:
A.Running MESI protocol simulation 
1. Put the exe file "mesi_chetan.exe" in a folder
2. Put any of the text file named "instr.txt " in the same folder
3. Execute the file mesi_chetan.exe file
4. See the end of output.log file which has misses,memory accesses
5. Total hits=No. of entries in the text file- no. of misses


B.Running MI protocol simulation
1. Put mi.exe in one folder 
2. Put any of the text file named "procID_address_rw_data.txt " in the same folder
3. Run the file mi.exe  
4. See the end of output.log file which has hits, misses,memory accesses
